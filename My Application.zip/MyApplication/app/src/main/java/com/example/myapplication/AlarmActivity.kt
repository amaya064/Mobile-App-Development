package com.example.myapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class AlarmActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.stop_alarm)

        val btnStopAlarm: Button = findViewById(R.id.btnStopAlarm)

        // Stop the ringtone when the user dismisses the alarm
        btnStopAlarm.setOnClickListener {
            AlarmReceiver().stopRingtone()
            finish() // Close the activity
        }
    }
}

// HomeActivity.kt
package com.example.myapplication


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HomePage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.homepage)

        val taskListButton = findViewById<Button>(R.id.taskListButton)

        taskListButton.setOnClickListener {
            val intent = Intent(this, TaskList::class.java)
            startActivity(intent)
        }

        val alarmButton = findViewById<Button>(R.id.alarmButton)
        alarmButton.setOnClickListener {
            val intent = Intent(this, Alarmset::class.java)
            startActivity(intent)
        }

        val timerButton = findViewById<Button>(R.id.timerButton)
        timerButton.setOnClickListener{
            val intent = Intent(this, TimerActivity::class.java)
            startActivity(intent)
        }
    }
}

package com.example.myapplication

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import android.app.TimePickerDialog
import android.widget.Button
import java.util.*

class Alarmset : AppCompatActivity() {

    private lateinit var tvAlarmStatus: TextView
    private lateinit var alarmManager: AlarmManager
    private val ALARM_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm)

        tvAlarmStatus = findViewById(R.id.tvAlarmStatus)
        val fabSetAlarm: FloatingActionButton = findViewById(R.id.fabSetAlarm)
        val btnDeleteAlarm: Button = findViewById(R.id.btnDeleteAlarm)

        alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager

        loadSavedAlarm()

        fabSetAlarm.setOnClickListener {
            openTimePickerDialog()
        }

        btnDeleteAlarm.setOnClickListener {
            deleteAlarm()
        }
    }

    private fun openTimePickerDialog() {
        val calendar = Calendar.getInstance()
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        val currentMinute = calendar.get(Calendar.MINUTE)

        TimePickerDialog(this, { _, hourOfDay, minute ->
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
            calendar.set(Calendar.MINUTE, minute)
            calendar.set(Calendar.SECOND, 0)

            Log.d("AlarmSet", "Setting alarm for $hourOfDay:$minute")

            setAlarm(calendar.timeInMillis)
            saveAlarmToPreferences(hourOfDay, minute)
            updateAlarmStatus(hourOfDay, minute)

        }, currentHour, currentMinute, false).show()
    }

    private fun setAlarm(timeInMillis: Long) {
        val intent = Intent(this, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this, ALARM_REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
        Log.d("AlarmSet", "Alarm set for ${Date(timeInMillis)}")
    }

    private fun saveAlarmToPreferences(hour: Int, minute: Int) {
        val sharedPref = getSharedPreferences("AlarmPrefs", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putInt("alarm_hour", hour)
            putInt("alarm_minute", minute)
            apply()
        }
    }

    private fun loadSavedAlarm() {
        val sharedPref = getSharedPreferences("AlarmPrefs", Context.MODE_PRIVATE)
        val savedHour = sharedPref.getInt("alarm_hour", -1)
        val savedMinute = sharedPref.getInt("alarm_minute", -1)

        if (savedHour != -1 && savedMinute != -1) {
            updateAlarmStatus(savedHour, savedMinute)
        }
    }

    private fun updateAlarmStatus(hour: Int, minute: Int) {
        val formattedTime = String.format("%02d:%02d", hour, minute)
        tvAlarmStatus.text = "Alarm set for $formattedTime"
    }

    private fun deleteAlarm() {
        // Show confirmation dialog before deleting the alarm
        AlertDialog.Builder(this)
            .setTitle("Delete Alarm")
            .setMessage("Are you sure you want to delete the alarm?")
            .setPositiveButton("Yes") { _, _ ->
                // Proceed with deletion
                val intent = Intent(this, AlarmReceiver::class.java)
                val pendingIntent = PendingIntent.getBroadcast(
                    this, ALARM_REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                alarmManager.cancel(pendingIntent)

                val sharedPref = getSharedPreferences("AlarmPrefs", Context.MODE_PRIVATE)
                with(sharedPref.edit()) {
                    remove("alarm_hour")
                    remove("alarm_minute")
                    apply()
                }

                tvAlarmStatus.text = "No alarm set"
                Log.d("AlarmSet", "Alarm deleted")
            }
            .setNegativeButton("No", null) // Dismiss the dialog
            .show()
    }
}
